<table>
    <thead>
    <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Address</th>
        <th>Store name</th>
        <th>Bank name</th>
        <th>Card number</th>
        <th>Bank address</th>
        <th>Status</th>
        <th>Register day</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->phone_number); ?></td>
            <td><?php echo e($user->address); ?></td>
            <td><?php echo e($user->store->translate('en')->store_name); ?></td>
            <td><?php echo e($user->bank_name); ?></td>
            <td><?php echo e($user->bank_number); ?></td>
            <td><?php echo e($user->bank_address); ?></td>
            <td>
                <?php if($user->actived == 1): ?>
                    actived
                <?php else: ?>
                    unactive
                <?php endif; ?>
            </td>
            <td><?php echo e(date('M j, Y h:ia', strtotime($user->created_at))); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mystery/resources/views/backend/exports/users.blade.php ENDPATH**/ ?>