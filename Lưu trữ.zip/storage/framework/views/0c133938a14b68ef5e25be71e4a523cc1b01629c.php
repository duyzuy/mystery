Hello Admin
We have new user register with <br>
Name:  <?php echo e($email_data['name']); ?><br>
Email:  <?php echo e($email_data['email']); ?><br>

<br>
<br>
Please login to scan and approval
<a href="http://localhost/mystery/manage/users">Login</a>

<br>
<br>
Thank you!<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mystery/resources/views/mails/signup.blade.php ENDPATH**/ ?>