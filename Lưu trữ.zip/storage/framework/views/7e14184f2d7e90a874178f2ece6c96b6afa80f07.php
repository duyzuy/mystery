<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-5">
          <div class="col-sm-6">
            <h1>Questions</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('manage.dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item"><a href="<?php echo e(route('manage.questionnaire.index')); ?>">Questionnaires</a></li>
              <li class="breadcrumb-item active">Question</li>
            </ol>
          </div>
        </div>
        <div class="row mb-2">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">
                      <div class="col-12 mb-2 mt-2 mb-3">
                        <h2><?php echo e($question->translate('en')->question); ?></h2>
                      </div>
                      <div class="col-12">
                        <div class="card">
                        
                          <div class="card-body p-0">
                            <table class="table table-striped projects">
                                <thead>
                                      <tr>
                                        <th style="width: 35%">Answer (VI)</th>
                                        <th style="width: 35%">Answer (EN)</th>
                                        <th style="width: 10%">Point</th>
                                        <th>Actions</th>
                                      </tr>
                                </thead>
                                <tbody>
                                  
                                    <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                       
                                          <td><?php echo e($answer->translate('vi')->answer); ?></td>
                                          <td><?php echo e($answer->translate('en')->answer); ?></td>
                                          <td><?php echo e($answer->point); ?></td>
                                        <td>
                                            <a class="btn btn-info" href=""><?php echo e(__('Edit')); ?></a>
                                          </td>
                                      </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                          </div>
                          <!-- /.card-body -->
                         
                        </div>
                        <!-- /.card -->
                      </div>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('manage.questions.index', $questionnaire->id)); ?>" class="btn btn-danger">Back</a>
                    </div>
                    </div>
                </div>
            </div>
        
          </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mystery/resources/views/backend/questions/show.blade.php ENDPATH**/ ?>