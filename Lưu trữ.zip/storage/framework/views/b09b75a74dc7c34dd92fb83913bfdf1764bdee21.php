<?php if(count($messages)): ?>



      
  <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
      <script>
         
         const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          onOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          }
        })

        Toast.fire({
            icon: '<?php echo e($message['level']); ?>',
            title: '<?php echo $message['message']; ?>',
        })
       
    </script>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>


<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mystery/resources/views/partials/messages.blade.php ENDPATH**/ ?>