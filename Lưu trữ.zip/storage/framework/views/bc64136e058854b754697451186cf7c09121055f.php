<?php $__env->startSection('title', 'Longin'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrap-login-page">
<div class="container is-fluid">
    <div class="columns">
        <div class="column is-three-fifths is-offset-one-fifth">
            <div class="card">
                <div class="card-header">
                    <h1 class="title is-size-4 has-text-centered"><?php echo app('translator')->get('user.loginPage.label'); ?></h1>
                </div>
                <div class="card-content">
                    <form method="POST" action="<?php echo e(route('user.login.submit', app()->getLocale())); ?>">
                        <?php echo csrf_field(); ?>
                        
                        <div class="field">
                            <label class="label"><?php echo app('translator')->get('user.loginPage.labelEmail'); ?></label>
                            <div class="control has-icons-left has-icons-right">
                              <input class="input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" type="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
                              <span class="icon is-small is-left">
                                <i class="fas fa-envelope"></i>
                              </span>
                            </div>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </div>
        
                        <div class="field">
                            <label class="label"><?php echo app('translator')->get('user.loginPage.labelPassword'); ?></label>
                            <div class="control has-icons-left has-icons-right">
                              <input class="input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password" autocomplete placeholder="Password">
                              <span class="icon is-small is-left">
                                <i class="fas fa-key"></i>
                              </span>
                            </div>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="help is-danger"><?php echo e($message); ?></p>       
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
        
                        <div class="field">
                            
                            <p class="control mt-5">
                                <button type="submit" class="button is-primary is-outlined is-fullwidth">
                                    <?php echo app('translator')->get('user.button.login'); ?>
                                </button>
        
                                <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>
                                </p>
                            <p class="control mt-3 has-text-centered">
                                <a class="is-size-7 has-text-primary" href="<?php echo e(route('user.register', app()->getLocale())); ?>"><?php echo app('translator')->get('user.button.haveNoAccount'); ?></a>
                            </p>
                        </div>
                    </form>
                </div>
            </div>    
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mystery/resources/views/auth/user/login.blade.php ENDPATH**/ ?>