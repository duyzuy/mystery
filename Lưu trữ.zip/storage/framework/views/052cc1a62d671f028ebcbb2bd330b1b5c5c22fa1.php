<?php $__env->startPush('styles'); ?>
  <style>
    .answer__group{
      display: flex
    }
    .answer__group .answer{
      flex: 1;
      max-width: 370px;
      padding-right: 20px
    }
    .responses{
      flex: 1;
      max-width: 220px;
    }
  </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-5">
          <div class="col-sm-6">
            <h1>Questionnairs</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Questionnairs</li>
            </ol>
          </div>
        </div>
        <div class="row mb-2">
            
            <!-- Default box -->
              <div class="col-12">
                <?php $__currentLoopData = $questionnaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $questionnaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                  <div class="card-header"><?php echo e($questionnaire->translate('en')->title); ?></div>
                  <div class="card-body">
                      <ul class="list-group">
                        <?php $__currentLoopData = $questionnaire->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li class="list-group-item">
                            <p class="bold is-bold"> <span><?php echo e($key+1); ?>. </span><?php echo e($question->translate('en')->question); ?></p>
                           
                              <ul class="list-group">
                              <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item answer__group">
                                  <p class="answer" style="margin-bottom: 0"><?php echo e($answer->translate('en')->answer); ?></p>
                                  <div class="responses">
                                    <div class="response__count"><?php echo e($answer->responses->count() .'/'. $question->responses->count()); ?>

                                    </div>
                                  
                                    <div class="progress progress-xs">
                                      <?php if($answer->key == 'yes'): ?>
                                        <div class="progress-bar bg-success" style="width: <?php echo e(($answer->responses->count()/$question->responses->count())*100); ?>%"></div>
                                      <?php elseif($answer->key == 'no'): ?>
                                        <div class="progress-bar bg-warning" style="width: <?php echo e(($answer->responses->count()/$question->responses->count())*100); ?>%"></div>
                                      <?php else: ?>
                                        <div class="progress-bar bg-primary" style="width: <?php echo e(($answer->responses->count()/$question->responses->count())*100); ?>%"></div>
                                      <?php endif; ?>
                                    
                                    </div>
                                  </div>
                                </li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                          </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                  </div>
                  <!-- /.card-body -->
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
                <!-- /.card -->
              </div>

          </div>
      </div><!-- /.container-fluid -->
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('plugins/chart.js/Chart.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/backend/pages/dashboard3.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mystery/resources/views/backend/questionnaires/report.blade.php ENDPATH**/ ?>