<?php $__env->startSection('title', 'Thank you'); ?>

<style>
    .header-page{
        background-image: url('../images/bg-guest-home.jpg');
        background-size: cover;
        background-position: top center;
        padding: 10rem 0 10rem;
        display: flex;
        align-items: center;
        justify-content: center
    }
    . h1{
        font-size: 10rem;
        opacity: .6;
    }

</style>


<?php $__env->startSection('content'); ?>
<section >
    <div class="header-page">
        <div class="container">
            <div class="columns is-centered">
                <div class="column is-7">
                    <div class="content has-text-centered has-text-white">
                        <h1 class="has-text-white">Thanks You</h1>
                        <?php echo app('translator')->get('page.thank.content'); ?>
                    </div>
                </div>
            </div>
           
        </div>
    </div>
   
</section>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mystery/resources/views/frontend/user/thankyou.blade.php ENDPATH**/ ?>