<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
<section class="hero is-primary header-profile">
    <div class="header-section">
        <div class="hero-body">
            <div class="container has-text-centered wrap__name">
              <h1 class="title is-uppercase has-text-centered name">
                <?php echo e(Auth::user()->name); ?>

              </h1>
            </div>
          </div>
    </div>
</section>
<section class="section">
    <div class="container">
        <div class="columns is-centered">
            <div class="column is-6">
                <div class="box box-info">
                    <h3 class="title is-size-5"><?php echo app('translator')->get('user.profile.title'); ?></h3>
                    <hr class="is-divider">
                    <div class="box-content">
                        <ul>
                            <li>
                                <span class="icon"><i class="fas fa-envelope"></i></span>
                                <span class="has-text-weight-bold"><?php echo app('translator')->get('user.profile.email'); ?>:</span> 
                                <span class="is-float-right "><?php echo e(Auth::user()->email); ?></span>
                               
                            </li>
                            <li>
                                <span class="icon"><i class="fas fa-map-marker-alt"></i></span>
                                <span class="has-text-weight-bold"><?php echo app('translator')->get('user.profile.address'); ?>:</span> 
                                <span class="is-float-right "><?php echo e(Auth::user()->address); ?></span>
                            </li>
                            <li>
                                <span class="icon"><i class="fas fa-utensils"></i></span>
                                <span class="has-text-weight-bold"><?php echo app('translator')->get('user.profile.restaurent'); ?>:</span> 
                                <span class="is-float-right "><?php echo e(Auth::user()->store->translate()->store_name); ?></span>
                            </li>
                            <li>
                                <span class="icon"><i class="fas fa-phone"></i></span>
                                <span class="has-text-weight-bold"><?php echo app('translator')->get('user.profile.phone'); ?>:</span>  
                                <span class="is-float-right "><?php echo e(Auth::user()->phone_number); ?></span>
                            </li>
                        </ul>
                    </div>
                    <hr class="is-divider">
                    <h3 class="title is-size-5"><?php echo app('translator')->get('user.pageRegister.label.bankInfo'); ?></h3>
                    <div class="box-content">
                        <ul>
                            <li>
                                <span class="icon"><i class="fas fa-university"></i></span>
                                <span class="has-text-weight-bold"><?php echo app('translator')->get('user.pageRegister.label.bankName'); ?>:</span>  
                                <span class="is-float-right "><?php echo e(Auth::user()->bank_name); ?></span>
                            </li>
                            <li>
                                <span class="icon"><i class="fas fa-money-check"></i></span> 
                                <span class="has-text-weight-bold"><?php echo app('translator')->get('user.pageRegister.label.bankCard'); ?>:</span> 
                                <span class="is-float-right"><?php echo e(Auth::user()->bank_number); ?></span>
                            </li>
                            <li>
                                <span class="icon"><i class="fas fa-map-marker"></i></span> 
                                <span class="has-text-weight-bold"><?php echo app('translator')->get('user.pageRegister.label.bankAddress'); ?>:</span> 
                                <span class="is-float-right "><?php echo e(Auth::user()->bank_address); ?></span>
                           
                            </li>
                          
                        </ul>
                    </div>
                    <hr class="is-divider">
                    <h3 class="title is-size-5"><?php echo app('translator')->get('user.survey.title'); ?></h3>
                    <div class="box-content">
                       
                        <ul class="questionnaire__list">
                            <?php $__currentLoopData = $questionnaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $questionnaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                                $user = new UserCheck(Auth::user()->id, $questionnaire->id);
                            ?>
                          
                            <li class="questionnaire__item">
                                <p class="questionnaire__title"><?php echo e($questionnaire->translate()->title); ?></p>
                                <?php if($user->is_Responsed()): ?>
                                    <span class="title is-size-5 has-text-danger"><?php echo e($user->get_Response()->total_point); ?> <?php echo app('translator')->get('user.survey.point'); ?></span>
                                <?php else: ?>
                                <a class="button is-small is-success" href="<?php echo e(route('user.survey.detail', [app()->getLocale(), $questionnaire->id, Str::slug($questionnaire->translate()->title)])); ?>"><?php echo app('translator')->get('user.button.takesurvey'); ?></a>
                                <?php endif; ?>
                               
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                 
                    </div>
            </div>
         
        </div>
    </div>
</section>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mystery/resources/views/frontend/user/profile.blade.php ENDPATH**/ ?>