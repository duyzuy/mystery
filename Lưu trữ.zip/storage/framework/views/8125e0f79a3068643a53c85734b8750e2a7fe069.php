<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('plugins/summernote/summernote-bs4.min.css')); ?>">
<style>
.note-editor{
    box-shadow: none !important;
}
    
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-5">
          <div class="col-sm-6">
            <h1>Questionnairs</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Questionnairs</li>
            </ol>
          </div>
        </div>
        <div class="row mb-2">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('manage.questionnaire.update', $questionnaire->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="card-body">
                              <div class="row">
                                <div class="col-12 col-lg-6 mb-5">
                                  <div class="form-group">
                                    <label for="vi_title"><?php echo e(__('Title (VI)')); ?></label>
                                    <input type="text" class="form-control" id="vi_title" name="vi_title" value="<?php echo e($questionnaire->translate('vi')->title); ?>" placeholder="Questionnaire title">
                                  </div>
                                  <div class="form-group">
                                    <label for="vi_title"><?php echo e(__('Description (VI)' )); ?></label>
                                    <textarea class="textarea__summernote" id="vi_description" name="vi_description"><?php echo e($questionnaire->translate('vi')->description); ?></textarea>
                                  </div>
                                </div>
                                <div class="col-12 col-lg-6 mb-5">
                                  <div class="form-group">
                                    <label for="title"><?php echo e(__('Title (EN)')); ?></label>
                                    <input type="text" class="form-control" id="en_title" name="en_title" value="<?php echo e($questionnaire->translate('en')->title); ?>" placeholder="Questionnaire title">
                                  </div>
                                  <div class="form-group">
                                    <label for="vi_title"><?php echo e(__('Description (EN)')); ?></label>
                                    <textarea class="textarea__summernote" id="en_description" name="en_description"><?php echo e($questionnaire->translate('en')->description); ?></textarea>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                <a href="<?php echo e(route('manage.questionnaire.index')); ?>" class="btn btn-danger">Cancel</a>
                                <button type="submit" class="btn btn-primary">Update</button>
                              
                            </div>
                          </form>
                    </div>
                </div>
                
                
            </div>
        
          </div>
      </div><!-- /.container-fluid -->
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('plugins/summernote/summernote-bs4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>

    <script>
        $('.textarea__summernote').summernote({
            height: 200,
            toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'underline', 'clear']],
                ['color', ['color']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['table', ['table']],
                ['insert', ['link']],
                ['view', ['fullscreen', 'codeview']]
            ],
            hint: {
                words: ['apple', 'orange', 'watermelon', 'lemon'],
                match: /\b(\w{1,})$/,
                search: function (keyword, callback) {
                callback($.grep(this.words, function (item) {
                    return item.indexOf(keyword) === 0;
                }));
                }
            }
        })

        $(function () {
            bsCustomFileInput.init();
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mystery/resources/views/backend/questionnaires/edit.blade.php ENDPATH**/ ?>