<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">

<style>
    textarea {
      resize: none;
    }
    .morecontent:not(.show){
        display: none;
       
    }
    .morecontent{
        padding: 10px 0;
    }
    .list-by-group, .list-by-question{
        list-style-type: none;
        padding: 0;
    }
    .list-by-question .question p{
        font-weight: bold
    }
    .list-by-question .question p span{

    }
    h4.group__label{
        background: #f1f1f1;
        padding: 15px 1.5rem;
        margin: 1.5rem -1.5rem;
        /* margin-left: -1.5rem;
        margin-right: -1.5rem; */
    }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section class="hero is-primary survey__header">
    <div class="hero-body">
      <div class="container">
        <h1 class="title has-text-centered">
            <?php echo $questionnaire->translate()->title; ?>

        </h1>
      </div>
    </div>
  </section>
<section class="section">
    <div class="container">

        <div class="container-survey">
            <div class="survey__description">
               <?php echo $questionnaire->translate()->description; ?>

            </div>
            
                <form method="POST" action="<?php echo e(route('user.survey.store', [ app()->getlocale(), $questionnaire->id, Str::slug($questionnaire->translate()->title)])); ?>">
                    <?php echo csrf_field(); ?>
                 
                    
                    <div class="card">
                      
                        <div class="card-content">
                            <div class="columns">
                                <div class="column is-one-third">
                                    <div class="field">
                                        <div class="control is-fullwidth">
                                            <label class="label" for="restaurentName"><?php echo app('translator')->get('user.label.restaurentName'); ?></label>
                                            <div class="select is-fullwidth <?php $__errorArgs = ['restaurent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <select name="restaurent" id="restaurentName" name="store">
                                                    <option value><?php echo app('translator')->get('user.input.selectRestaurent'); ?></option>
                                                      <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <optgroup label="<?php echo e($city->translate('en')->name); ?>">
                                                            <?php $__currentLoopData = $city['stores']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($store->id); ?>" <?php echo e(old('restaurent') == $store->id ? 'selected' : ''); ?>><?php echo e($store->translate()->store_name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </optgroup>
                                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['restaurent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="help is-danger"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div> 
                                </div>
                                <div class="column is-one-third">
                                    <div class="field">
                                        <div class="control">
                                            <label class="label" for="restaurentAddress"><?php echo app('translator')->get('user.label.addressTitle'); ?></label>
                                            <input type="text" id="restaurentAddress" name="address" class="input <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('address')); ?>" placeholder="<?php echo app('translator')->get('user.input.address'); ?>">
                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="help is-danger"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="column is-one-third">
                                    <div class="field">
                                        <div class="control">
                                            <label  class="label" for="restaurentTime"><?php echo app('translator')->get('user.label.timeTitle'); ?></label>
                                            <input type="date" id="restaurentTime" name="time" value="<?php echo e(old('time')); ?>" class="input <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['restaurent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="help is-danger"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="columns">
                                <div class="column is-one-third">
                                    <div class="field"> 
                                        <div class="control">
                                            <label class="label" for="restaurentManage"><?php echo app('translator')->get('user.label.managerName'); ?></label>
                                            <input type="text" id="restaurentManage" name="manage_name" value="<?php echo e(old('manage_name')); ?>" class="input <?php $__errorArgs = ['manage_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="<?php echo app('translator')->get('user.input.managerName'); ?>">
                                            <?php $__errorArgs = ['manage_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="help is-danger"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="column is-one-third">
                                    <div class="field">
                                        <div class="control">
                                            <label class="label" for="restaurentStaff"><?php echo app('translator')->get('user.label.staffName'); ?></label>
                                            <input type="text" id="restaurentStaff" name="staff_name" value="<?php echo e(old('staff_name')); ?>" class="input <?php $__errorArgs = ['staff_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="<?php echo app('translator')->get('user.input.staffName'); ?>">
                                            <?php $__errorArgs = ['staff_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="help is-danger"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            <hr class="">
                            <ul class="question__lists list__by__group">
                            
                            <?php $i = 0; ?>
                            <?php $__currentLoopData = $allQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h4 class="group__label"><?php echo e($group['group']->translate()->title); ?></h4>
                                <ul class="list-by-question list-question-<?php echo e($key + 1); ?>">

                                    <?php $__currentLoopData = $group['questions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <li class="question question-<?php echo e($key + 1); ?> mb-4">
                                            <p class="question__title"><span><?php echo e($i + 1); ?>.</span> <?php echo e($question->translate()->question); ?></p>
                                            <?php $__errorArgs = ['responses.' . $i . '.answer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                               <p class="help is-danger"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="form-group">
                                                    <div class="icheck-primary">
                                                        <input class="form-control" type="radio" id="answer-<?php echo e($answer->id); ?>"<?php echo e(($answer->show_textarea == 1) ? "onchange=showDetail($question->id,$i)" : "onchange=removeDetail($question->id,$i)"); ?> name="responses[<?php echo e($i); ?>][answer_id]" <?php echo e(old('responses.' . $i . '.answer_id') == $answer->id ? 'checked' : ''); ?> value="<?php echo e($answer->id); ?>">
                                                        <label for="answer-<?php echo e($answer->id); ?>">
                                                            <?php echo e($answer->translate()->answer); ?>

                                                        </label>
                                                    </div>
                                                    <?php if($answer->show_textarea == 1): ?>
                                                        <div class="morecontent formContent-<?php echo e($question->id); ?>">
                                                            <textarea id="textContent-<?php echo e($question->id); ?>" name="responses[<?php echo e($i); ?>][descriptions]" class="textarea answer_more_content" rows="3" cols="50"></textarea>
                                                        </div>
                                                        
                                                    <?php endif; ?>
                                                </div>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                            <input type="hidden" name="responses[<?php echo e($i); ?>][question_id]" value="<?php echo e($question->id); ?>">
                                            <input type="hidden" name="responses[<?php echo e($i); ?>][group_id]" value="<?php echo e($group['group']->id); ?>">
                                        </li>
                                
                                        <?php $i++; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                            <hr class="navbar-divider mt-5 mb-5">
                            <div class="field">
                                <label for="userFeedback" class="label"><?php echo app('translator')->get('user.survey.anotherQuestion'); ?></label>
                                <textarea name="user_feedback" id="userFeedback" rows="5" class="textarea"><?php echo e(old('user_feedback')); ?></textarea>
                            </div>

                            <div class="field">
                                <div class="control">
                                    <button type="submit" class="button is-primary"><?php echo app('translator')->get('user.survey.buttonSubmit'); ?></button>
                                </div>
                            </div>
                        </div>
                      
                    </div>
                </form>
            
          
        </div>
     
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
      
    //   const app = new Vue({
    //     el: '#app',
    //     data: {
    //         checkFormContent: [],
    //     }, 
    //     methods: {
    //         // showdetail(Id){
    //         //     $('#textContent'+Id).remove();
    //         // }
    //     }
    //   });

      function showDetail(Id, InputId){
            // var formDetail = document.getElementById('textContent-'+Id);
            var formDetailClass = $('.formContent-'+Id);
           if( $('input[name="responses['+InputId+'][answer_id]"]').is(':checked') )
            {
                formDetailClass.addClass('show');

            }else{
                formDetailClass.removeClass('show');
           
            } 
      }

      function removeDetail(Id, InputId){
            // var formDetail = document.getElementById('textContent-'+Id);
            var formDetailClass = $('.formContent-'+Id);
           if( $('input[name="responses['+InputId+'][answer_id]"]').is(':checked') )
            {
                formDetailClass.removeClass('show');

            }
      }

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mystery/resources/views/frontend/survey/show.blade.php ENDPATH**/ ?>