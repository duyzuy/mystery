  <nav class="navbar is-transparent">
    <div class="navbar-brand">
      <a class="navbar-item" href="<?php echo e(route("home", app()->getLocale())); ?>">
        <img src="<?php echo e(asset('img/logo.png')); ?>" alt="AFG logo" width="112" height="28">
      </a>

      <div class="navbar-item has-dropdown is-hoverable nav-lang-mobile">
        
        <a class="navbar-link" data-toggle="dropdown">
          <?php if(app()->getLocale() == 'en'): ?>
            <span class="navbar-lang">
              <i class="flag-icon flag-icon-us"></i> EN
            </span>
          <?php else: ?>
            <span class="navbar-lang">
              <i class="flag-icon flag-icon-vn"></i> VI
            </span>
          <?php endif; ?>
        </a>
        <div class="navbar-dropdown is-boxed">
          <a href="<?php echo e(route('home', 'vi')); ?>" class="navbar-item dropdown-item">
            <i class="flag-icon flag-icon-vn mr-2"></i> Tiếng việt
          </a>
          <a href="<?php echo e(route('home', 'en')); ?>" class="navbar-item dropdown-item">
            <i class="flag-icon flag-icon-us mr-2"></i> English
          </a>       
        </div>
      </div>

      <div class="navbar-burger burger" data-target="mobileMenu">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
    <div id="mobileMenu" class="navbar-menu">
        <div class="navbar-start">
          <a class="navbar-item" href="#">
            <?php echo app('translator')->get('menu.menuItem.store'); ?>
          </a>
          <a class="navbar-item" href="#">
            <?php echo app('translator')->get('menu.menuItem.contact'); ?>
          </a>
          <li class="navbar-item">
              <?php echo app('translator')->get('menu.menuItem.support'); ?>
            
            <a class="" href="#">
              <span class="icon"><i class="fab fa-facebook-f"></i></span>
            </a>
            <a class="" href="#">
              <span class="icon"><i class="fab fa-linkedin-in"></i></span>
            </a>
          </li>
          <hr class="is-divider">
          <?php if(auth()->guard()->check()): ?>
            <div class="navbar-item">
                <strong class="d-none d-md-inline"> <?php echo app('translator')->get('menu.hello'); ?>, <?php echo e(Auth::user()->name); ?></strong>
            </div>
      
              <a class="navbar-item" href="<?php echo e(route('user.profile', app()->getLocale())); ?>"> <?php echo app('translator')->get('menu.menuItem.profile'); ?></a>
          
                <a class="navbar-item" href="<?php echo e(route('user.logout', app()->getLocale())); ?>"
                  onclick="event.preventDefault();
                              document.getElementById('user-logout-form').submit();">
                  <?php echo app('translator')->get('user.logout'); ?> 
                </a>
            
                <form id="user-logout-form" action="<?php echo e(route('user.logout', app()->getLocale())); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
        
          
        <?php else: ?>   
          <div class="navbar-item">
            <div class="field is-grouped">
              <p class="control">
                <a class="button is-primary is-outlined is-small" href="<?php echo e(route('user.login', app()->getLocale())); ?>"> <?php echo app('translator')->get('user.login'); ?></a>
              </p>
              <p class="control">
                <a class="button is-primary is-small" href="<?php echo e(route('user.register', app()->getLocale())); ?>"> <?php echo app('translator')->get('user.register'); ?></a>
              </p>
            </div>
          </div>
    
        <?php endif; ?>
        
        </div>
    </div>
    <div id="desktopMenu" class="navbar-menu">
      <div class="navbar-start">
     
       
      </div>
  
      <div class="navbar-end">
        <a class="navbar-item" href="#">
          <?php echo app('translator')->get('menu.menuItem.store'); ?>
        </a>
        <a class="navbar-item" href="#">
          <?php echo app('translator')->get('menu.menuItem.contact'); ?>
        </a>
        <li class="navbar-item ">
            <?php echo app('translator')->get('menu.menuItem.support'); ?>
          <a class="navbar-item" href="#">
            <span class="icon"><i class="fab fa-facebook-f"></i></span>
          </a>
          <a class="navbar-item" href="#">
            <span class="icon"><i class="fab fa-linkedin-in"></i></span>
          </a>
        </li>
        <span class="navbar-item">|</span>
        <?php if(auth()->guard()->check()): ?>
        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link" href="#">
            <span class="d-none d-md-inline"> <?php echo app('translator')->get('menu.hello'); ?>, <?php echo e(Auth::user()->name); ?></span>
          </a>
          <div class="navbar-dropdown is-boxed">
            <a class="navbar-item" href="<?php echo e(route('user.profile', app()->getLocale())); ?>"> <?php echo app('translator')->get('menu.menuItem.profile'); ?></a>
            <hr class="navbar-divider">
            <a class="navbar-item" href="<?php echo e(route('user.logout', app()->getLocale())); ?>"
              onclick="event.preventDefault();
                          document.getElementById('user-logout-form').submit();">
              <?php echo app('translator')->get('user.logout'); ?> 
            </a>
        
            <form id="user-logout-form" action="<?php echo e(route('user.logout', app()->getLocale())); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
          </div>
        </div>
      <?php else: ?>   
      <div class="navbar-item">
        <div class="field is-grouped">
          <p class="control">
            <a class="button is-primary is-outlined is-small" href="<?php echo e(route('user.login', app()->getLocale())); ?>"> <?php echo app('translator')->get('user.login'); ?></a>
          </p>
          <p class="control">
            <a class="button is-primary is-small" href="<?php echo e(route('user.register', app()->getLocale())); ?>"> <?php echo app('translator')->get('user.register'); ?></a>
          </p>
        </div>
      </div>
   
      <?php endif; ?>
      <div class="navbar-item has-dropdown is-hoverable">
        
   

       
        <a class="navbar-link" data-toggle="dropdown">
          <?php if(app()->getLocale() == 'en'): ?>
            <span class="navbar-lang">
              <i class="flag-icon flag-icon-us"></i> EN
            </span>
          <?php else: ?>
            <span class="navbar-lang">
              <i class="flag-icon flag-icon-vn"></i> VI
            </span>
          <?php endif; ?>
        </a>
        <div class="navbar-dropdown is-boxed">

          <?php if( Route::currentRouteName() == 'user.survey.detail'): ?>

            <?php 
    
              $slug = Request::segment(3);
    
    
              $id = preg_match_all('!\d+!', $slug, $matches);
              $id = implode(' ', $matches[0]);
    
              $slug = preg_replace('!\d+!', '', $slug);
              $slug = substr($slug, 1);
    
            ?>
          

            <a href="<?php echo e(route(Route::currentRouteName(), ['vi', $id, $slug])); ?>" class="navbar-item dropdown-item">
              <i class="flag-icon flag-icon-vn mr-2"></i> Tiếng việt
            </a>
            <a href="<?php echo e(route(Route::currentRouteName(), ['en', $id, $slug])); ?>" class="navbar-item dropdown-item">
              <i class="flag-icon flag-icon-us mr-2"></i> English
            </a>       

          <?php else: ?>

            <a href="<?php echo e(route(Route::currentRouteName(), 'vi')); ?>" class="navbar-item dropdown-item">
              <i class="flag-icon flag-icon-vn mr-2"></i> Tiếng việt
            </a>
            <a href="<?php echo e(route(Route::currentRouteName(), 'en')); ?>" class="navbar-item dropdown-item">
              <i class="flag-icon flag-icon-us mr-2"></i> English
            </a>       


          <?php endif; ?>




        </div>
      </div>

       
      </div>
    </div>
  </nav>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mystery/resources/views/frontend/_include/header.blade.php ENDPATH**/ ?>