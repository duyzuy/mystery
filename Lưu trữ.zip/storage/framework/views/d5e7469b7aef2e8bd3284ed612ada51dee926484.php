Hello <?php echo e($email_data['name']); ?> <br>
Congratulations you are successfully actived <br>
Your account:  <br>
Email:  <?php echo e($email_data['email']); ?><br>
password:  <?php echo e($email_data['password']); ?><br>

<br>
<br>
login and answer the question by click the <a href="<?php echo e($email_data['survey']); ?>">servey</a>

<br>
<br>
Thank you!<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mystery/resources/views/mails/verified.blade.php ENDPATH**/ ?>