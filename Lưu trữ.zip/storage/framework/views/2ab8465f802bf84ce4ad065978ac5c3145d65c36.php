<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

   

    <title><?php echo e(config('app.name', 'AFG Viet Nam')); ?>

        
        <?php if (! empty(trim($__env->yieldContent('title')))): ?>     
           - <?php echo $__env->yieldContent('title'); ?>

        <?php else: ?>
        - AFG Viet Nam
        <?php endif; ?>

    </title>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/flag-icon-css/css/flag-icon.min.css')); ?>">


    <!-- Styles -->
    <link href="<?php echo e(asset('css/frontend/overrides.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/frontend/login.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/alert.css')); ?>">
    <script src="<?php echo e(asset('js/alert.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <div id="app">
        <div class="wrapper">
            <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <header id="header" class="<?php if(Route::currentRouteName() == 'home'): ?>home <?php endif; ?>">
                <div class="container">
                    <?php echo $__env->make('frontend._include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </header>
      
            <main id="main">
                
                <?php echo $__env->yieldContent('content'); ?>
            </main>
    
            <footer id="footer">
                <?php echo $__env->make('frontend._include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </footer>
    </div>
</div>


<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mystery/resources/views/frontend/master.blade.php ENDPATH**/ ?>