<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section class="section page-404">


    <div class="container">
        <div class="content has-text-centered">
            <h1 class="has-text-white has-text-centered" style="font-weight: 300">404</h1>
            <a href="<?php echo e(route('home', app()->getLocale())); ?>" class="button button is-transparent has-text-white is-outlined"> Back to homepage</a>
        </div>
    </div>
</section>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mystery/resources/views/errors/404.blade.php ENDPATH**/ ?>