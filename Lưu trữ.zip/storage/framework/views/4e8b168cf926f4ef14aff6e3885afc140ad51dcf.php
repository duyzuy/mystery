<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php $__currentLoopData = $questionnaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $questionnaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="content">
            <h1>Survey</h1>
        </div>
        <ul>
            <li><?php echo e($questionnaire->translate()->title); ?> 
                <a href="<?php echo e(route('user.survey.detail', [app()->getLocale(), $questionnaire->id, Str::slug($questionnaire->translate()->title)])); ?>"><?php echo app('translator')->get('user.button.takesurvey'); ?></a>
            </li>

        </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mystery/resources/views/frontend/survey/index.blade.php ENDPATH**/ ?>