<?php 
return [
    'hello' =>  'Hi!',
    'menuItem'  =>  [
        'why'       =>      'Why is maystery guest?',
        'work'      =>      'How it work',
        'what'      =>      'What we need',
        'contact'   =>      'Contact',
        'store'     =>      'Restaurent',
        'support'   =>      'Support chanel', 
        'profile'   =>      'Profile'
    ]
];