<?php 
return [
    'titleContact' =>  'Contact Information'
];