<?php 
return [
    'hello' =>  'Xin chào!',
    'menuItem'  =>  [
        'why'       =>      'Tại sao tham gia',
        'work'      =>      'Cách tham gia',
        'what'      =>      'Chúng',
        'contact'   =>      'Liên hệ',
        'store'     =>      'Nhà hàng',
        'support'   =>      'Kênh hỗ trợ',
        'profile'   =>      'Thông tin cá nhân'
    ]
];