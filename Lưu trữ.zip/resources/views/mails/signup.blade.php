Hello Admin
We have new user register with <br>
Name:  {{ $email_data['name'] }}<br>
Email:  {{ $email_data['email'] }}<br>

<br>
<br>
Please login to scan and approval
<a href="http://localhost/mystery/manage/users">Login</a>

<br>
<br>
Thank you!