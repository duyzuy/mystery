<?php

namespace App\Helpers;
use App\Survey;
use App\questionnaire;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Session;


class SwitchLanguage
{   
    public $locale;
    // public $questionnaire_id;


    // public function __construct($locale)
    // {
    //     $this->locale = $locale;
      
      
    // }

    
    public function getRequest(Request $request){
    
        
    }
 
}